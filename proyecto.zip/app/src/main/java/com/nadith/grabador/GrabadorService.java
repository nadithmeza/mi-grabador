package com.nadith.grabador;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;

import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Graba el audio interno del celular y lo guarda en M4A (AAC, 128 kbps). */
public class GrabadorService extends Service {

    public interface Escucha {
        /** uri != null: grabación lista. error != null: algo falló. */
        void fin(String uri, String error);
    }

    public static volatile Escucha escucha;
    private static volatile boolean activo = false;

    private static final int FRECUENCIA = 44100;
    private static final int CANALES = 2;
    private static final String CANAL_ID = "grabacion";

    private MediaProjection proyeccion;
    private AudioRecord grabador;
    private MediaCodec codec;
    private MediaMuxer muxer;
    private int pista = -1;
    private boolean muxerIniciado = false;
    private long muestras = 0;

    public static void pedirParar() {
        activo = false;
    }

    public static boolean estaGrabando() {
        return activo;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || activo) return START_NOT_STICKY;

        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CANAL_ID, "Grabación", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CANAL_ID)
                .setContentTitle("Mi Grabador")
                .setContentText("Grabando audio del celular")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);

        final int codigo = intent.getIntExtra("code", 0);
        final Intent datos = intent.getParcelableExtra("data");
        activo = true;
        new Thread(() -> grabar(codigo, datos)).start();
        return START_NOT_STICKY;
    }

    private void grabar(int codigo, Intent datos) {
        Uri uri = null;
        ParcelFileDescriptor pfd = null;
        String error = null;
        try {
            MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
            proyeccion = mpm.getMediaProjection(codigo, datos);
            proyeccion.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    activo = false;
                }
            }, new Handler(Looper.getMainLooper()));

            AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(proyeccion)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build();
            AudioFormat formatoPcm = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(FRECUENCIA)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build();
            int minimo = AudioRecord.getMinBufferSize(FRECUENCIA, AudioFormat.CHANNEL_IN_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT);
            grabador = new AudioRecord.Builder()
                    .setAudioFormat(formatoPcm)
                    .setBufferSizeInBytes(Math.max(minimo * 2, 32768))
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build();

            MediaFormat formato = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, FRECUENCIA, CANALES);
            formato.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            formato.setInteger(MediaFormat.KEY_BIT_RATE, 128000);
            formato.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            codec.configure(formato, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            codec.start();

            String nombre = "Grabacion_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".m4a";
            uri = Recortador.nuevoArchivo(this, nombre);
            if (uri == null) throw new Exception("No se pudo crear el archivo");
            pfd = getContentResolver().openFileDescriptor(uri, "w");
            muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            byte[] pcm = new byte[8192];
            grabador.startRecording();
            while (activo) {
                int leidos = grabador.read(pcm, 0, pcm.length);
                if (leidos > 0) enviar(pcm, leidos);
            }
            grabador.stop();
            terminarCodificacion();

            if (!muxerIniciado) throw new Exception("No se captó audio. Revisa que la página esté sonando.");
            muxer.stop();
            muxerIniciado = false;
            Recortador.terminar(this, uri);
        } catch (Exception e) {
            error = e.getMessage() != null ? e.getMessage() : "No se pudo grabar";
            if (uri != null) Recortador.borrar(this, uri);
            uri = null;
        } finally {
            activo = false;
            liberar();
            try {
                if (pfd != null) pfd.close();
            } catch (Exception ignorada) {
            }
            Escucha e = escucha;
            if (e != null) e.fin(uri != null ? uri.toString() : null, error);
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
    }

    /** Entrega audio al compresor en trozos y guarda lo que va saliendo. */
    private void enviar(byte[] datos, int cantidad) {
        int pos = 0;
        while (pos < cantidad) {
            int idx = codec.dequeueInputBuffer(10000);
            if (idx >= 0) {
                ByteBuffer entrada = codec.getInputBuffer(idx);
                entrada.clear();
                int largo = Math.min(entrada.remaining(), cantidad - pos);
                largo = (largo / 4) * 4;
                if (largo == 0) break;
                entrada.put(datos, pos, largo);
                long tiempoUs = muestras * 1000000L / FRECUENCIA;
                codec.queueInputBuffer(idx, 0, largo, tiempoUs, 0);
                muestras += largo / 4;
                pos += largo;
            }
            vaciar();
        }
    }

    private void terminarCodificacion() {
        int idx = -1;
        for (int i = 0; i < 100 && idx < 0; i++) idx = codec.dequeueInputBuffer(10000);
        if (idx >= 0) {
            long tiempoUs = muestras * 1000000L / FRECUENCIA;
            codec.queueInputBuffer(idx, 0, 0, tiempoUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
        }
        for (int i = 0; i < 200; i++) {
            if (vaciar()) break;
            try {
                Thread.sleep(10);
            } catch (InterruptedException ignorada) {
            }
        }
    }

    /** Pasa lo comprimido al archivo. Devuelve true cuando ya no hay más. */
    private boolean vaciar() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (true) {
            int salida = codec.dequeueOutputBuffer(info, 0);
            if (salida == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                pista = muxer.addTrack(codec.getOutputFormat());
                muxer.start();
                muxerIniciado = true;
            } else if (salida >= 0) {
                ByteBuffer datos = codec.getOutputBuffer(salida);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                if (info.size > 0 && muxerIniciado) {
                    datos.position(info.offset);
                    datos.limit(info.offset + info.size);
                    muxer.writeSampleData(pista, datos, info);
                }
                codec.releaseOutputBuffer(salida, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true;
            } else {
                return false;
            }
        }
    }

    private void liberar() {
        try {
            if (grabador != null) grabador.release();
        } catch (Exception ignorada) {
        }
        try {
            if (codec != null) {
                codec.stop();
                codec.release();
            }
        } catch (Exception ignorada) {
        }
        try {
            if (muxer != null) muxer.release();
        } catch (Exception ignorada) {
        }
        try {
            if (proyeccion != null) proyeccion.stop();
        } catch (Exception ignorada) {
        }
    }
}
