package com.nadith.grabador;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.nio.ByteBuffer;

/** Crea archivos en Música/MiGrabador y corta audio M4A sin volver a comprimir. */
public class Recortador {

    static final String CARPETA = "Music/MiGrabador";

    /** Crea un archivo vacío (pendiente) en la carpeta Música/MiGrabador. */
    static Uri nuevoArchivo(Context c, String nombre) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
        v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4");
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, CARPETA);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        return c.getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
    }

    /** Marca el archivo como terminado para que aparezca en la galería y en otras apps. */
    static void terminar(Context c, Uri uri) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.IS_PENDING, 0);
        c.getContentResolver().update(uri, v, null, null);
    }

    static void borrar(Context c, Uri uri) {
        try {
            c.getContentResolver().delete(uri, null, null);
        } catch (Exception ignorada) {
        }
    }

    /** Copia solo el tramo [iniMs, finMs] a un archivo nuevo. No pierde calidad. */
    static Uri recortar(Context c, Uri origen, long iniMs, long finMs, String nombre) throws Exception {
        ContentResolver cr = c.getContentResolver();
        MediaExtractor ex = new MediaExtractor();
        ParcelFileDescriptor pfdIn = cr.openFileDescriptor(origen, "r");
        Uri destino = null;
        ParcelFileDescriptor pfdOut = null;
        MediaMuxer muxer = null;
        boolean muxerIniciado = false;
        try {
            ex.setDataSource(pfdIn.getFileDescriptor());
            int pista = -1;
            MediaFormat formato = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    pista = i;
                    formato = f;
                    break;
                }
            }
            if (pista < 0) throw new Exception("El archivo no tiene audio");
            ex.selectTrack(pista);

            destino = nuevoArchivo(c, nombre);
            if (destino == null) throw new Exception("No se pudo crear el archivo");
            pfdOut = cr.openFileDescriptor(destino, "w");
            muxer = new MediaMuxer(pfdOut.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int pistaSalida = muxer.addTrack(formato);
            muxer.start();
            muxerIniciado = true;

            long iniUs = iniMs * 1000L;
            long finUs = finMs * 1000L;
            ex.seekTo(iniUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

            ByteBuffer buf = ByteBuffer.allocate(1 << 16);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int escritas = 0;
            while (true) {
                buf.clear();
                int n = ex.readSampleData(buf, 0);
                if (n < 0) break;
                long t = ex.getSampleTime();
                if (t > finUs) break;
                info.offset = 0;
                info.size = n;
                info.presentationTimeUs = Math.max(0, t - iniUs);
                info.flags = ex.getSampleFlags();
                muxer.writeSampleData(pistaSalida, buf, info);
                escritas++;
                ex.advance();
            }
            if (escritas == 0) throw new Exception("El tramo elegido está vacío");
            muxer.stop();
            muxerIniciado = false;
            muxer.release();
            muxer = null;
            pfdOut.close();
            pfdOut = null;
            terminar(c, destino);
            return destino;
        } catch (Exception e) {
            try {
                if (muxer != null) {
                    if (muxerIniciado) muxer.stop();
                    muxer.release();
                }
            } catch (Exception ignorada) {
            }
            try {
                if (pfdOut != null) pfdOut.close();
            } catch (Exception ignorada) {
            }
            if (destino != null) borrar(c, destino);
            throw e;
        } finally {
            ex.release();
            try {
                pfdIn.close();
            } catch (Exception ignorada) {
            }
        }
    }
}
