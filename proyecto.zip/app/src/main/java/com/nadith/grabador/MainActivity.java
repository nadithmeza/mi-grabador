package com.nadith.grabador;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int PEDIR_CAPTURA = 1;
    private static final int PEDIR_PERMISOS = 2;

    private WebView ui;          // tu interfaz en HTML (assets/index.html)
    private WebView nav;         // la página que quieres grabar (Suno, etc.)
    private LinearLayout panelNav;
    private TextView txtTiempo;
    private Button btnGrabar;
    private boolean grabando = false;
    private long inicio;
    private MediaPlayer reproductor;
    private final Handler h = new Handler(Looper.getMainLooper());

    private final Runnable relojTic = new Runnable() {
        @Override
        public void run() {
            if (!grabando) return;
            long s = (System.currentTimeMillis() - inicio) / 1000;
            txtTiempo.setText(String.format(Locale.US, "%02d:%02d", s / 60, s % 60));
            h.postDelayed(this, 500);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        FrameLayout raiz = new FrameLayout(this);
        raiz.setBackgroundColor(Color.parseColor("#eef0f6"));

        ui = new WebView(this);
        WebSettings s = ui.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        ui.setWebChromeClient(new WebChromeClient());
        ui.addJavascriptInterface(new Puente(), "Android");
        ui.loadUrl("file:///android_asset/index.html");
        raiz.addView(ui, new FrameLayout.LayoutParams(-1, -1));

        panelNav = new LinearLayout(this);
        panelNav.setOrientation(LinearLayout.VERTICAL);
        panelNav.setBackgroundColor(Color.WHITE);
        panelNav.setVisibility(View.GONE);

        LinearLayout barra = new LinearLayout(this);
        barra.setOrientation(LinearLayout.HORIZONTAL);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setBackgroundColor(Color.parseColor("#1b1d3a"));
        barra.setPadding(dp(8), dp(8), dp(8), dp(8));

        Button btnVolver = new Button(this);
        btnVolver.setText("Volver");
        btnVolver.setOnClickListener(v -> {
            if (grabando) {
                Toast.makeText(this, "Para la grabación antes de salir", Toast.LENGTH_SHORT).show();
            } else {
                cerrarNav();
            }
        });
        barra.addView(btnVolver, new LinearLayout.LayoutParams(-2, -2));

        txtTiempo = new TextView(this);
        txtTiempo.setText("00:00");
        txtTiempo.setTextColor(Color.WHITE);
        txtTiempo.setTextSize(18);
        txtTiempo.setGravity(Gravity.CENTER);
        barra.addView(txtTiempo, new LinearLayout.LayoutParams(0, -2, 1f));

        btnGrabar = new Button(this);
        btnGrabar.setText("Grabar");
        btnGrabar.setOnClickListener(v -> alternarGrabacion());
        barra.addView(btnGrabar, new LinearLayout.LayoutParams(-2, -2));

        panelNav.addView(barra, new LinearLayout.LayoutParams(-1, -2));

        nav = new WebView(this);
        WebSettings n = nav.getSettings();
        n.setJavaScriptEnabled(true);
        n.setDomStorageEnabled(true);
        n.setMediaPlaybackRequiresUserGesture(false);
        n.setUserAgentString(n.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(nav, true);
        nav.setWebViewClient(new WebViewClient());
        nav.setWebChromeClient(new WebChromeClient());
        panelNav.addView(nav, new LinearLayout.LayoutParams(-1, 0, 1f));

        raiz.addView(panelNav, new FrameLayout.LayoutParams(-1, -1));
        setContentView(raiz);

        GrabadorService.escucha = (uri, error) -> runOnUiThread(() -> alTerminar(uri, error));
    }

    // ---------- grabar ----------

    private void alternarGrabacion() {
        if (grabando) {
            btnGrabar.setEnabled(false);
            btnGrabar.setText("Guardando…");
            GrabadorService.pedirParar();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS},
                    PEDIR_PERMISOS);
            return;
        }
        pedirCaptura();
    }

    private void pedirCaptura() {
        MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
        startActivityForResult(mpm.createScreenCaptureIntent(), PEDIR_CAPTURA);
    }

    @Override
    public void onRequestPermissionsResult(int codigo, String[] permisos, int[] resultados) {
        super.onRequestPermissionsResult(codigo, permisos, resultados);
        if (codigo == PEDIR_PERMISOS) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                pedirCaptura();
            } else {
                Toast.makeText(this, "Sin permiso de audio no se puede grabar", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int codigo, int resultado, Intent datos) {
        super.onActivityResult(codigo, resultado, datos);
        if (codigo == PEDIR_CAPTURA) {
            if (resultado == RESULT_OK && datos != null) {
                Intent i = new Intent(this, GrabadorService.class);
                i.putExtra("code", resultado);
                i.putExtra("data", datos);
                startForegroundService(i);
                grabando = true;
                inicio = System.currentTimeMillis();
                btnGrabar.setText("Parar");
                btnGrabar.setEnabled(true);
                h.post(relojTic);
            } else {
                Toast.makeText(this, "Permiso de captura cancelado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void alTerminar(String uri, String error) {
        grabando = false;
        btnGrabar.setText("Grabar");
        btnGrabar.setEnabled(true);
        txtTiempo.setText("00:00");
        if (error != null) {
            Toast.makeText(this, error, Toast.LENGTH_LONG).show();
            return;
        }
        cerrarNav();
        ui.evaluateJavascript("grabacionLista(" + JSONObject.quote(uri) + ")", null);
    }

    private void cerrarNav() {
        nav.loadUrl("about:blank");
        panelNav.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (panelNav.getVisibility() == View.VISIBLE) {
            if (grabando) {
                Toast.makeText(this, "Para la grabación antes de salir", Toast.LENGTH_SHORT).show();
            } else if (nav.canGoBack()) {
                nav.goBack();
            } else {
                cerrarNav();
            }
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (reproductor != null) reproductor.release();
        GrabadorService.escucha = null;
    }

    // ---------- puente entre tu HTML y Android ----------

    private class Puente {

        @JavascriptInterface
        public void abrir(String direccion) {
            final String url = direccion.matches("(?i)^https?://.*") ? direccion : "https://" + direccion;
            runOnUiThread(() -> {
                panelNav.setVisibility(View.VISIBLE);
                nav.loadUrl(url);
            });
        }

        @JavascriptInterface
        public String listar() {
            JSONArray lista = new JSONArray();
            try (Cursor c = getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
                            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.SIZE},
                    MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?",
                    new String[]{Recortador.CARPETA + "%"},
                    MediaStore.Audio.Media.DATE_ADDED + " DESC")) {
                while (c != null && c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("uri", ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0)).toString());
                    o.put("nombre", c.getString(1));
                    o.put("dur", c.getLong(2));
                    o.put("peso", c.getLong(3));
                    lista.put(o);
                }
            } catch (Exception ignorada) {
            }
            return lista.toString();
        }

        @JavascriptInterface
        public int duracion(String uri) {
            try {
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                r.setDataSource(MainActivity.this, Uri.parse(uri));
                String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                r.release();
                return d == null ? 0 : Integer.parseInt(d);
            } catch (Exception e) {
                return 0;
            }
        }

        @JavascriptInterface
        public void reproducir(final String uri, final int iniMs, final int finMs) {
            runOnUiThread(() -> {
                try {
                    if (reproductor != null) reproductor.release();
                    reproductor = new MediaPlayer();
                    reproductor.setDataSource(MainActivity.this, Uri.parse(uri));
                    reproductor.prepare();
                    reproductor.seekTo(iniMs);
                    reproductor.start();
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                if (reproductor != null && reproductor.isPlaying()) {
                                    if (reproductor.getCurrentPosition() >= finMs) {
                                        reproductor.pause();
                                    } else {
                                        h.postDelayed(this, 80);
                                    }
                                }
                            } catch (Exception ignorada) {
                            }
                        }
                    });
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo reproducir", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void detener() {
            runOnUiThread(() -> {
                try {
                    if (reproductor != null && reproductor.isPlaying()) reproductor.pause();
                } catch (Exception ignorada) {
                }
            });
        }

        @JavascriptInterface
        public int posicion() {
            try {
                if (reproductor != null && reproductor.isPlaying()) return reproductor.getCurrentPosition();
            } catch (Exception ignorada) {
            }
            return -1;
        }

        @JavascriptInterface
        public void recortar(final String uri, final int iniMs, final int finMs, String nombre) {
            String limpio = nombre == null ? "" : nombre.replaceAll("[\\\\/:*?\"<>|]", "").trim();
            if (limpio.isEmpty()) {
                limpio = "Recorte_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            }
            final String archivo = limpio + ".m4a";
            new Thread(() -> {
                boolean ok = true;
                String msg = "Guardado: " + archivo;
                try {
                    Recortador.recortar(MainActivity.this, Uri.parse(uri), iniMs, finMs, archivo);
                } catch (Exception e) {
                    ok = false;
                    msg = e.getMessage() != null ? e.getMessage() : "No se pudo cortar";
                }
                final boolean fOk = ok;
                final String fMsg = msg;
                runOnUiThread(() -> ui.evaluateJavascript(
                        "recorteListo(" + fOk + "," + JSONObject.quote(fMsg) + ")", null));
            }).start();
        }

        @JavascriptInterface
        public void compartir(String uri) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("audio/mp4");
                i.putExtra(Intent.EXTRA_STREAM, Uri.parse(uri));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "Compartir audio"));
            });
        }

        @JavascriptInterface
        public boolean borrar(String uri) {
            try {
                return getContentResolver().delete(Uri.parse(uri), null, null) > 0;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
